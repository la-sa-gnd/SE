package view;
import controller.LogInCont;
import controller.MenuController;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import model.Creds;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;

import java.awt.CardLayout;
import javax.swing.JList;
import javax.swing.JSpinner;
import javax.swing.JTable;

public class MenuScreen extends JFrame{
	private JTabbedPane tabbedPane;
	private JTextField Search;
	private MenuController MenuCont;
	//private JTable table=new JTable();
	private DefaultTableModel modelSearch = new DefaultTableModel(); 
	private DefaultTableModel modelInfo = new DefaultTableModel(); 
	
	
	
	 /**
	 * @param conn
	 * @param name
	 * @param type
	 */
	public MenuScreen(Connection conn,String name,int type){
	        super(name);
	        MenuCont=new MenuController(conn);
	        setResizable(false);
	        setSize(800,600);
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setLocationRelativeTo(null);
	        getContentPane().setLayout(null);
	        
	        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	        tabbedPane.setBounds(0, 0, 800, 600);
	        
	        getContentPane().add(tabbedPane);
	        
	        JPanel panelOne = new JPanel();
	        JPanel panelTwo = new JPanel();
	        JPanel panelThree = new JPanel();
	        JPanel panelFour = new JPanel();
	        JPanel panelFive = new JPanel();
	        JPanel panelSix = new JPanel();
	        
	        //Insert
	        JTextField Field1=new JTextField();
	        Field1.setBounds(300, 10, 200, 20);
	        JTextField Field2=new JTextField();
	        Field2.setBounds(300, 60, 200, 20);
	        JTextField Field3=new JTextField();
	        Field3.setBounds(300, 110, 200, 20);
	        JTextField Field4=new JTextField();
	        Field4.setBounds(300, 160, 200, 20);
	        panelOne.setLayout(null);
	        panelOne.add(Field1);
	        panelOne.add(Field2);
	        panelOne.add(Field3);
	        panelOne.add(Field4);
	        JButton Button = new JButton("Insert");
	        Button.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e){
	        		MenuCont.Insert(Field1,Field2,Field3,Field4);
	        		
	        	}});
	        Button.setBounds(350, 200, 100, 23);
	        panelOne.add(Button);
	        
	        JLabel lblNewLabel1 = new JLabel("�����");
	        lblNewLabel1.setBounds(150, 10, 100, 20);
	        JLabel lblNewLabel2 = new JLabel("�������");
	        lblNewLabel2.setBounds(150, 60, 100, 20);
	        JLabel lblNewLabel3 = new JLabel("AMKA");
	        lblNewLabel3.setBounds(150, 110, 100, 20);
	        JLabel lblNewLabel4 = new JLabel("���������� ��������(YYYY-MM-DD)");
	        lblNewLabel4.setBounds(50, 160, 250, 20);
	        panelOne.add(lblNewLabel1);
	        panelOne.add(lblNewLabel2);
	        panelOne.add(lblNewLabel3);
	        panelOne.add(lblNewLabel4);
	        //
	        //CHANGE
	        panelSix.setLayout(null);
	        JTextField changeID=new JTextField();
	        changeID.setBounds(300, 10, 200, 20);
	        JTextField changeName=new JTextField();
	        changeName.setBounds(300, 60, 200, 20);
	        JTextField changeSurname=new JTextField();
	        changeSurname.setBounds(300, 110, 200, 20);
	        JTextField changeAMKA=new JTextField();
	        changeAMKA.setBounds(300, 160, 200, 20);
	        JTextField changeDOB=new JTextField();
	        changeDOB.setBounds(300, 210, 200, 20);
	        
	        JLabel L1 = new JLabel("ID ������");
	        L1.setBounds(150, 10, 100, 20);
	        JLabel L2 = new JLabel("��� �����");
	        L2.setBounds(150, 60, 100, 20);
	        JLabel L3 = new JLabel("��� �������");
	        L3.setBounds(150, 110, 100, 20);
	        JLabel L4 = new JLabel("��� ����");
	        L4.setBounds(150, 160, 250, 20);
	        JLabel L5 = new JLabel("��� ���������� ��������(YYYY-MM-DD)");
	        L5.setBounds(50, 210, 250, 20);
	        
	        JButton ChangeButton = new JButton("Change");
	        ChangeButton.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e){
	        		MenuCont.Change(changeID,changeName,changeSurname,changeAMKA,changeDOB);
	        		
	        	}});
	        ChangeButton.setBounds(350, 250, 100, 23);
	        
	        
	        panelSix.add(changeID);
	        panelSix.add(changeName);
	        panelSix.add(changeSurname);
	        panelSix.add(changeAMKA);
	        panelSix.add(changeDOB);
	        
	        panelSix.add(L1);
	        panelSix.add(L2);
	        panelSix.add(L3);
	        panelSix.add(L4);
	        panelSix.add(L5);
	        panelSix.add(ChangeButton);
	        
	        //
	        //DELETE
	        
	        JTextField IDField=new JTextField();
	        IDField.setBounds(300, 10, 200, 20);
	        JLabel IDLabel = new JLabel("ID ������");
	        IDLabel.setBounds(150, 10, 100, 20);
	        panelTwo.setLayout(null);
	        panelTwo.add(IDField);
	        panelTwo.add(IDLabel);
	        IDField.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e){
	        		MenuCont.Delete(IDField);
	        		
	        	}});
	        
	        //Search
	        modelSearch.addColumn("ID"); 
	        modelSearch.addColumn("�����"); 
	        modelSearch.addColumn("�������");
	    	modelSearch.addColumn("����");
	    	modelSearch.addColumn("���������� ��������");
	    	JTable tableSearch = new JTable(modelSearch);
	    	tableSearch.setEnabled(false);
	    	
	    	tableSearch.setBounds(0, 50, 800, 400);
	        JScrollPane scrollPane = new JScrollPane(tableSearch);
	        scrollPane.setLocation(0, 100);
	        scrollPane.setSize(800, 400);
	        panelThree.add(scrollPane);
	        
	        JTextField Search=new JTextField();
	        Search.setBounds(300, 5, 200, 20);
	        Search.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e){
	        		MenuCont.Search(Search,tableSearch,panelThree,modelSearch);
	        		
	        	}});
	        panelThree.setLayout(null);
	        panelThree.add(Search);
	        //
	        //Insert INFO
	        JTextField PatientID=new JTextField();
	        PatientID.setBounds(300, 10, 200, 20);
	        JTextField Exam=new JTextField();
	        Exam.setBounds(300, 60, 200, 20);
	        JTextField Date=new JTextField();
	        Date.setBounds(300, 110, 200, 20);
	        
	        
	        JLabel PatientIDLabel = new JLabel("������� ������");
	        PatientIDLabel.setBounds(150, 10, 100, 20);
	        JLabel ExaminationLabel = new JLabel("������� ��������");
	        ExaminationLabel.setBounds(150, 60, 100, 20);
	        JLabel DateLabel = new JLabel("����������(YYYY-MM-DD)");
	        DateLabel.setBounds(100, 110, 150, 20);
	       
	        JButton SubmitButton = new JButton("Submit");
	        SubmitButton.setBounds(350, 200, 100, 23);
	        SubmitButton.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e){
	        		MenuCont.InsertData(PatientID,Exam,Date);
	        		
	        	}});
	        
	        panelFour.setLayout(null);
	        panelFour.add(PatientID);
	        panelFour.add(Exam);
	        panelFour.add(Date);
	        
	        panelFour.add(PatientIDLabel);
	        panelFour.add(ExaminationLabel);
	        panelFour.add(DateLabel);
	        panelFour.add(SubmitButton);
	        
	        //
	        //INFO
	        JLabel Patient = new JLabel("");
	        Patient.setBounds(150, 30, 300, 20);
	        modelInfo.addColumn("��������"); 
	        modelInfo.addColumn("����������(YYYY-MM-DD)"); 
	        JTable tableInfo = new JTable(modelInfo);
	        tableInfo.setEnabled(false);
	    	
	    	tableInfo.setBounds(0, 50, 800, 400);
	        JScrollPane scrollPane2 = new JScrollPane(tableInfo);
	        scrollPane2.setLocation(0, 100);
	        scrollPane2.setSize(800, 400);
	        panelFive.add(scrollPane2);
	        panelFive.add(Patient);
	        
	        JTextField InfoSearch=new JTextField();
	        InfoSearch.setBounds(300, 5, 200, 20);
	        panelFive.setLayout(null);
	        panelFive.add(InfoSearch);
	        InfoSearch.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e){
	        		MenuCont.InfoSearch(Patient,InfoSearch,tableInfo,panelFive,modelInfo);
	        		
	        	}});
	        
	       
	        
	        MenuController MenuCont=new MenuController(conn);
	        if(type==1) {
	        	tabbedPane.add(panelOne,"���������� �������");
	        	tabbedPane.add(panelSix,"����������� �������");
		        tabbedPane.add(panelTwo,"�������� �������");
		        tabbedPane.add(panelThree,"���������");
		        tabbedPane.add(panelFour,"�������� �����������");
		        tabbedPane.add(panelFive,"��������");
		    }else if(type==2) {
		    	tabbedPane.add(panelThree,"���������");
		        tabbedPane.add(panelFour,"�������� �����������");
		        tabbedPane.add(panelFive,"��������");
		    }else if(type==3) {
		    	tabbedPane.add(panelThree,"���������");
		    	tabbedPane.add(panelFive,"��������");
		    }
	        
	        
	    }
}
