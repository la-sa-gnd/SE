package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import view.MenuScreen;
import model.Creds;

public class MenuController {
	Connection conn;
	
	public MenuController(Connection conn){
		this.conn=conn;
		System.out.println(this.conn);
	}
	
	public void Search(JTextField Search,JTable table,JPanel panelThree,DefaultTableModel model) {
		String Text=Search.getText();
		Statement stm;
		Search.setText("");
		for( int i1 = model.getRowCount() - 1; i1 >= 0; i1-- )
		{
		    model.removeRow(i1);
		}
		if(Text.equals("")) {
			try {
				stm = conn.createStatement();
				ResultSet rs=stm.executeQuery("select * from patients;");
				while(rs.next()) {
					
					model.addRow(new Object[]{rs.getString("ID"),rs.getString("Name"), rs.getString("Surname"), rs.getString("AMKA"),rs.getString("DOB")});
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}else {
			try {
				
				stm = conn.createStatement();
				String Q="SELECT * FROM patients where patients.Name LIKE \""+Text+"%\" OR patients.Surname LIKE \""+Text+"%\" OR patients.AMKA=\""+Text+"\" OR patients.DOB=\""+Text+"\" OR ID=\""+Text+"\";";
				
				ResultSet rs=stm.executeQuery(Q);
				
				
				
				int i=0,j;
				
				while(rs.next()) {
		
					model.addRow(new Object[]{rs.getString("ID"),rs.getString("Name"), rs.getString("Surname"), rs.getString("AMKA"),rs.getString("DOB")});
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
	}
	
	public void InfoSearch(JLabel patient,JTextField Search,JTable table,JPanel panelThree,DefaultTableModel model) {
		String InfoText=Search.getText();
		Search.setText("");
		Statement stm;
		try {
			for( int i1 = model.getRowCount() - 1; i1 >= 0; i1-- )
			{
			    model.removeRow(i1);
			}
			stm = conn.createStatement();
			ResultSet rs=stm.executeQuery("select * from patients WHERE ID = \""+InfoText+"\" OR AMKA=\""+InfoText+"\";");
			rs.next();
			int id=rs.getInt("ID");
			patient.setText(rs.getString("Name")+" "+rs.getString("Surname"));
			stm = conn.createStatement();
			ResultSet rs1=stm.executeQuery("select * from history inner join examinations on history.ExamID = examinations.ExamID where history.ID=\""+id+"\" ORDER BY history.Date DESC;");
			
			
			int i=0,j;
			
			while(rs1.next()) {
				
					model.addRow(new Object[]{rs1.getString("Description"),rs1.getString("Date")});
					
			}
			System.out.println("DONEQ");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void Insert(JTextField field1,JTextField field2,JTextField field3,JTextField field4) {
		String name=field1.getText();
		String surname=field2.getText();
		String AMKA=field3.getText();
		String DOB=field4.getText();
		
		Statement stm;
		try {
		stm = conn.createStatement();
		stm.executeUpdate("insert into patients values(DEFAULT,\'"+name+"\',\'"+surname+"\',\'"+AMKA+"\',\'"+DOB+"\');");
		field1.setText("");
		field2.setText("");
		field3.setText("");
		field4.setText("");
		}catch (Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void Delete(JTextField id) {
		Statement stm;
		String ID=id.getText();
		try {
			stm = conn.createStatement();
			stm.executeUpdate("DELETE FROM patients WHERE ID="+ID+";");
			id.setText("");
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public void InsertData(JTextField id,JTextField Ex,JTextField date) {
		Statement stm;
		String ID=id.getText();
		String Exam=Ex.getText();
		String Date=date.getText();
		
		try {
			stm = conn.createStatement();
			ResultSet rs=stm.executeQuery("SELECT * FROM patients WHERE patients.ID ="+ID+";");
			if(rs.next()) {
				stm.executeUpdate("INSERT INTO history values(\'"+ID+"\',\'"+Date+"\',\'"+Exam+"\');");
			}
			id.setText("");
			Ex.setText("");
			date.setText("");
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public void Change(JTextField id,JTextField nName,JTextField nSur,JTextField nAMKA,JTextField nDOB) {
		String ID=id.getText();
		String newName=nName.getText();
		String newSur=nSur.getText();
		String newAMKA=nAMKA.getText();
		String newDOB=nDOB.getText();
		String oldName;
		String oldSur;
		String oldAMKA;
		String oldDOB;
		Statement stm;
		try {
			stm = conn.createStatement();
			ResultSet rs=stm.executeQuery("SELECT * FROM patients WHERE patients.ID ="+ID+";");
			if(rs.next()) {
				oldName=rs.getString("Name");
				oldSur=rs.getString("Surname");
				oldAMKA=rs.getString("AMKA");
				oldDOB=rs.getString("DOB");
				System.out.print(oldName+""+oldSur+"");
				if(newName.equals("")) {
					newName=oldName;
				}
				if(newSur.equals("")) {
					newSur=oldSur;
				}
				if(newAMKA.equals("")) {
					newAMKA=oldAMKA;
				}
				if(newDOB.equals("")) {
					newDOB=oldDOB;
				}
				
				stm = conn.createStatement();
				stm.executeUpdate("UPDATE patients SET Name = \""+newName+"\",Surname=\""+newSur+"\",AMKA=\""+newAMKA+"\",DOB=\""+newDOB+"\" WHERE patients.ID ="+ID+";");
				id.setText("");
				nName.setText("");
				nSur.setText("");
				nAMKA.setText("");
				nDOB.setText("");
			}
		}catch (Exception e){
			e.printStackTrace();
		
		}
		
		
		
	}
}

