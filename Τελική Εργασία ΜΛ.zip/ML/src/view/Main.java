package view;

import java.awt.EventQueue;
import java.sql.Connection;

public class Main {
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginScreen screen = new LoginScreen();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
