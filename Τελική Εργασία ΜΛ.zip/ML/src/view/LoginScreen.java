package view;

import controller.LogInCont;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;

public class LoginScreen {
	private JFrame frame;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField textField_1;
	private JLabel lblNewLabel;
	private LogInCont Controller;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	
	public LoginScreen() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setBounds(100, 100, 500, 300);
		frame.setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(null);
		lblNewLabel = new JLabel("");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 28));
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(150, 201, 200, 50);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(150, 50, 200, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JPasswordField();
		textField_1.setBounds(150, 80, 200, 20);
		textField_1.setEchoChar('*');
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		
		
		JButton btnNewButton = new JButton("Log In");
		btnNewButton.addActionListener(Controller= new LogInCont(textField,textField_1,lblNewLabel,contentPane,frame));	
		btnNewButton.setBounds(200, 120, 100, 23);
		contentPane.add(btnNewButton);
		
		
	}
	
	
}
