package controller;
import model.Creds;

import view.MenuScreen;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.Statement;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;




public class LogInCont extends JFrame implements java.awt.event.ActionListener{

	private JFrame LoginFrame;
	private JTextField userText,passText;
	private JLabel Text;
	private String URL="jdbc:mysql://localhost:3306/ml";
	private JPanel Pane;
	private Creds cred;
	private MenuScreen Menu;
	public LogInCont(JTextField textField,JTextField textField2,JLabel lblNewLabel,JPanel pane,JFrame frame) {
		this.userText = textField;
		this.passText = textField2;
		this.Text=lblNewLabel;
		this.Pane=pane;
		this.LoginFrame=frame;
	}


	@Override
	public void actionPerformed(ActionEvent arg0) {
		String user=userText.getText();
		String pass=passText.getText();
		userText.setText("");
		passText.setText("");
		cred=new Creds();
		
		int status=cred.Log(URL,user,pass);
		if(status==1) {
			Connection conn = cred.getConnection();
			try {
				Statement stm=conn.createStatement();
				ResultSet rs=stm.executeQuery("select * from accounts where Name = \""+user+"\";");	
				rs.next();
				int type=rs.getInt("Type");
				String name=rs.getString("Name");
				System.out.println(conn);
				Menu=new MenuScreen(conn,name,type);
				Menu.setVisible(true);
				LoginFrame.dispose();
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}else {
			Text.setForeground(Color.red);
			Text.setText("ERROR");
		}
	}


	
	
}
