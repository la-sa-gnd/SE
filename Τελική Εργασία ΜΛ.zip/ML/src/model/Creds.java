package model;
import view.LoginScreen;
import controller.LogInCont;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Creds {
	private Connection conn;
	
	public int Log(String URL,String User,String Pass) {
		try{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/ML?useUnicode=true&characterEncoding=utf-8", User, Pass);
			Statement stm=conn.createStatement();
			ResultSet rs=stm.executeQuery("select type from accounts where Name = \""+User+"\";");	
			System.out.println("successful");
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
		return 1;
	}
	
	public Connection getConnection() {
		return this.conn;
	}
}

